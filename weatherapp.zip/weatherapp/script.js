const API_KEY = "5ebe28439b7c7c1e51394c532d474f40"; 
    const BASE_URL = "https://api.openweathermap.org/data/2.5/weather";

    const cityInput = document.getElementById("cityInput");
    const searchBtn = document.getElementById("searchBtn");
    const weatherResult = document.getElementById("weatherResult");

    // Get weather data
    async function getWeather(city) {
      const url = `${BASE_URL}?q=${encodeURIComponent(city)}&appid=${API_KEY}&units=metric`;

      try {
        const response = await fetch(url);
        const data = await response.json();

        if (!response.ok) {
          throw new Error(data.message || "City not found");
        }

        // Show weather card
        weatherResult.innerHTML = `
          <div class="weather-card">
            <h2>${data.name}, ${data.sys.country}</h2>
            <p><strong>Temperature:</strong> ${Math.round(data.main.temp)} <sup>°C</sup></p>
            <p><strong>Description:</strong> ${data.weather[0].description}</p>
            <p><strong>Humidity:</strong> ${data.main.humidity}%</p>
            <p><strong>Wind Speed:</strong> ${data.wind.speed} m/s</p>
          </div>
        `;
      } catch (error) {
        weatherResult.innerHTML = `<p class="error">Error: ${error.message}</p>`;
        console.error("Weather API error:", error);
      }
    }

    // Event listeners
    searchBtn.addEventListener("click", () => {
      const city = cityInput.value.trim();
      if (city) {
        getWeather(city);
      } else {
        weatherResult.innerHTML = `<p class="error">Please enter a city, state, or country.</p>`;
      }
    });

    cityInput.addEventListener("keyup", (e) => {
      if (e.key === "Enter") {
        searchBtn.click();
      }
    });